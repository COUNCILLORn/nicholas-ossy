package com.shillo.shield

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val navy = Color.rgb(13, 35, 64)
    private val blue = Color.rgb(21, 101, 192)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(Color.rgb(245, 248, 252))
        }
        val scroll = ScrollView(this)
        scroll.addView(page)

        page.addView(text("SHILLO SHIELD", 28f, navy, true))
        page.addView(text("Basic phone security helper", 16f, Color.DKGRAY, false))
        page.addView(spacer(18))
        page.addView(text("Link safety check", 20f, navy, true))
        page.addView(text("Paste a link to check for common warning signs. This is a simple heuristic, not a guarantee that a link is safe.", 14f, Color.DKGRAY, false))

        val linkInput = EditText(this).apply {
            hint = "https://example.com"
            singleLine = true
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.WHITE)
        }
        page.addView(linkInput, matchWrap())
        page.addView(spacer(8))
        val result = text("Result will appear here.", 15f, navy, false)
        page.addView(button("Check link") {
            result.text = inspectLink(linkInput.text.toString())
        })
        page.addView(result)
        page.addView(spacer(22))
        page.addView(text("Security checklist", 20f, navy, true))
        listOf(
            "Keep Android and apps updated.",
            "Install apps only from trusted sources.",
            "Do not share verification codes or passwords.",
            "Review app permissions and remove apps you do not trust.",
            "Back up important files regularly."
        ).forEach { page.addView(text("•  $it", 15f, Color.DKGRAY, false)) }
        page.addView(spacer(18))
        page.addView(text("Limitations: SHILLO Shield does not scan all files, inspect other apps, block attacks system-wide, or replace Google Play Protect or a reputable mobile security product.", 13f, Color.DKGRAY, false))

        setContentView(scroll)
    }

    private fun inspectLink(raw: String): String {
        val value = raw.trim()
        if (value.isEmpty()) return "Enter a link first."
        val lower = value.lowercase()
        val warnings = mutableListOf<String>()
        if (!lower.startsWith("https://")) warnings.add("It does not start with HTTPS.")
        if (Regex("https?://\\d{1,3}(\\.\\d{1,3}){3}").containsMatchIn(lower)) warnings.add("It uses a numeric IP address.")
        if (lower.contains("@")) warnings.add("It contains an @ sign, which can be misleading in URLs.")
        if (lower.contains("xn--")) warnings.add("It contains an encoded domain name that may imitate another site.")
        if (listOf("login", "verify", "urgent", "password", "wallet", "claim-prize").any { lower.contains(it) }) warnings.add("It contains wording often used in deceptive messages.")
        return if (warnings.isEmpty()) {
            "No obvious warning signs found. This does NOT prove the link is safe; only open links you trust."
        } else {
            "Caution — possible warning signs:\n• " + warnings.joinToString("\n• ") + "\nDo not enter passwords or payment details unless you independently trust the site."
        }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, 6, 0, 6)
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setBackgroundColor(blue)
        gravity = Gravity.CENTER
        setOnClickListener { action() }
    }

    private fun spacer(height: Int) = android.view.View(this).apply {
        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
