# SHILLO Shield (starter)

A minimal Android security-helper starter with a heuristic link warning screen. It is not a full antivirus product and does not scan other apps, inspect the whole device, or block attacks system-wide.

## Build an APK with GitHub Actions

1. Upload the **contents of this folder** to the root of a GitHub repository (the `.github/workflows/android.yml` file must remain in that exact path).
2. Commit the files to the `main` branch.
3. Open the repository's **Actions** tab. Select **Build SHILLO Shield APK** and run it with **Run workflow** if it has not started automatically.
4. When the workflow succeeds, open its run, scroll to **Artifacts**, and download `shillo-shield-debug-apk`.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`, then open it on your Android phone to install. Android may ask you to allow installation from your browser or file manager; only do this for builds you trust.

GitHub web upload generally does not unpack a project ZIP into the repository. Extract this ZIP first, then upload the project files while preserving folders. The `.github/workflows` folder is hidden in some phone file managers; make sure it is included. If mobile upload cannot select folders, use a Git client or a browser-based development environment that supports importing/extracting archives.

## What the app does

- Checks a pasted URL for a few common warning signs.
- Shows basic security reminders.
- Requests no special Android permissions and makes no network requests.

A clean result does not mean a URL is safe. This project is an educational starter, not a substitute for Android security updates or Google Play Protect.
